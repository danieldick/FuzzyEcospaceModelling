#*************************************************************************
#*   FEM: Fuzzy Ecospace Modelling (EXAMPLE)                                       *
#*   FEM Version 1.0.0 (C)2017 Daniel G. Dick and Marc Laflamme          *
#*************************************************************************
# FEM = Fuzzy Ecospace Modelling. 
# Taxa must be coded as a Hutchinsonian n-dimensional hypervolume, as can be seen in (Stockwell 2007). 
# The resulting numerical array forms the base of this analysis.
# Matrices can include 2+ dimensions, but evidence suggests >4 dimensions are needed to accurately
# capture an organism's ecology (Maire et al. 2015). Divide data into two groups; an
# unclassified sample of organisms from a given environment, and a training
# data set of organisms from similar environments with known ecological
# variables.
# REFERENCES:
# Stockwell, D. 2007. Niche Modelling. Chapman & Hall/CRC.
# Maire, E., G. Grenouillet, S. Brosse, and S. Vill�ger. 2015. How many dimensions are needed to accurately assess functional 
# diversity? A pragmatic approach for assessing the quality of functional spaces. Global Ecology and Biogeography. 24:728-740. 
# Label your known ecological samples as "Training_Matrix", and your unknown observations as "Test_Matrix", and save them as tab delimited text files.

library(gower)
library(clue)
library(lpSolve)
Training_Matrix <- read.table("Training_Matrix.txt")
Test_Matrix <- read.table("Test_Matrix.txt")

# Identify ordinal and nominal characters. REMOVE IF NOT RUNNING EXAMPLE. 
Training_Matrix$V11 <- factor(Training_Matrix$V11,ordered=TRUE)
Training_Matrix$V12 <- factor(Training_Matrix$V12,ordered=TRUE)
Training_Matrix$V15 <- factor(Training_Matrix$V15,ordered=TRUE)
Training_Matrix$V20 <- factor(Training_Matrix$V20,ordered=TRUE)
Training_Matrix$V23 <- factor(Training_Matrix$V23,ordered=TRUE)
Training_Matrix$V39 <- factor(Training_Matrix$V39,ordered=TRUE)

Test_Matrix$V11 <- factor(Test_Matrix$V11,ordered=TRUE)
Test_Matrix$V12 <- factor(Test_Matrix$V12,ordered=TRUE)
Test_Matrix$V15 <- factor(Test_Matrix$V15,ordered=TRUE)
Test_Matrix$V20 <- factor(Test_Matrix$V20,ordered=TRUE)
Test_Matrix$V23 <- factor(Test_Matrix$V23,ordered=TRUE)
Test_Matrix$V39 <- factor(Test_Matrix$V39,ordered=TRUE)
# REMOVE THE ABOVE IF NOT RUNNING INCLUDED EXAMPLE.

dim <- dim(Training_Matrix)
cat_dim <- dim[2]+1
gow_mat <- matrix(0,dim[1],dim[1])

# Step 1: Calculates pairwise Gower dissimilarities for all taxa in the Training Matrix.
dim <- dim(Training_Matrix)
for (i in 1:dim[1]){gow_mat[i,] <- gower_dist(Training_Matrix[i,],Training_Matrix)}

# Step 2: Calculates optimal value of "k" based on percent variance explained of clusters.
distortion <- matrix(0,dim[1],1)

for (ii in 1:dim[1]){

meds <- kmedoids(gow_mat,ii)

mat_temp <- unlist(meds[1])
mat_temp2 <- unlist(meds[2])

C <- Training_Matrix[mat_temp2,]

dim_temp <- dim(C)

SUMD <- matrix(0,dim_temp[1],1)

IDX <- unlist(meds[1])

matrix_temp <- cbind(Training_Matrix,mat_temp)

for (j in 1:dim_temp[1]){
	SUMD_temp <- subset(matrix_temp,mat_temp==j)
		dim_sum <- dim(SUMD_temp)
		SUMD_mat <- matrix(0,dim_sum[1],1)
		SUMD_temp[,cat_dim] <- NULL	
		tst <- Training_Matrix[mat_temp2[j],] 
		SUMD_mat <- gower_dist(tst,SUMD_temp)
		SUMD[j] <- sum(SUMD_mat,na.rm=TRUE)}
distortion[ii] <- sum(SUMD)}

var1 <- distortion[1:dim[1]-1,]
var2 <- distortion[2:dim[1],]

variance_temp <- distortion[1:dim[1]-1,]-distortion[2:dim[1],]

variance <- t(t(variance_temp))

distortion_percent_temp <- apply(variance,2,cumsum)
distortion_percent <- distortion_percent_temp/(distortion[1,]-distortion[dim[1],])

PVE <- 0.90
k_temp <- which(distortion_percent>PVE)
k <- k_temp[1]

# Step 3: Calculates final medoids and clusters.

meds_final <- kmedoids(gow_mat,k)

# Step 4: Creates New Fuzzy Discriminant Model And Fits Fuzzy Discriminant Classifier
# Step 4A: Computes fuzzy membership functions for groups in the Training Matrix.    

mat_final <- unlist(meds_final[1])
mat_final2 <- unlist(meds_final[2])

C <- Training_Matrix[mat_final2,]
IDX <- unlist(meds_final[1])
D <- matrix(0,dim[1],k)

for (i in 1:dim[1]){D[i,] <- gower_dist(Training_Matrix[i,],C)}

# Step 4B: Calculate distances for all points.

Dij <- D

dim <- dim(Dij)

DBG2 <- cbind(D,mat_final)

# Step 4C: Find most dissimilar members of each group.

AI <- matrix(0,1,dim[2])

for (i in 1:dim[2]){
G_temp <- subset(DBG2,mat_final==i)
AI_val <- max(G_temp[,i])
AI[i] <- AI_val}

# Step 4D: Calculate criterion variable for each sample for each group.

yij <- matrix(0,dim[1],dim[2])

for (j in 1:dim[1]){
    for (i in 1:dim[2]){
        if(mat_final[j]==i){
        yij_temp <- 1}
        else
        {yij_temp <- 0}
        yij[j,i] <- yij_temp;}}

write.table(yij,file = "yij.txt",row.names=FALSE, col.names=FALSE)
write.table(AI,file = "AI.txt",row.names=FALSE, col.names=FALSE)
write.table(Dij,file = "Dij.txt",row.names=FALSE, col.names=FALSE)

# Step 4E: Finds extent of the fuzzy support for each cluster.

Ei <- function(bi,j){
Ei_mat <- matrix(0,dim[1],1)
AI <- read.table("AI.txt")
Dij <- read.table("Dij.txt")
yij <- read.table("yij.txt")
for (i in 1:dim[1]){
Dij_temp <- Dij[i,j]
yij_temp <- yij[i,j]
ai <- AI[j]
val1 <- abs(Dij_temp-bi)
val1 <- val1*0.5
val1_2 <- bi-ai
val1 <- val1/val1_2
val2 <- abs(Dij_temp-ai)
val2 <- val2*0.5
val2_2 <- bi-ai
val2 <- val2/val2_2
val <- val1-val2
val <- val+0.5
val <- val-yij_temp
Ei_calc <- val^2
Ei_mat[i,] <- Ei_calc}
Ei <- sum(Ei_mat)}

# Step 4F: Calculates Membership Scores for Groups in the Training Matrix.

memX <- matrix(0,dim[1],dim[2])

BIm_mat <- matrix(0,1,dim[2])

for (j in 1:dim[2]){
	BIm_temp <- max(gow_mat)
	AI_temp <- AI[j]
	BIm <- optimize(Ei,c(BIm_temp,AI_temp),tol=0.0001,j = j)
	BIm_mat[j] <- BIm$minimum}

for (i in 1:dim[1]){
for (j in 1:dim[2]){
	Dij_temp <- Dij[i,j]
	BIm <- BIm_mat[j]
	AIm <- AI[j]
	if(Dij_temp <= AIm){
            memX[i,j] <- 1}
            else if (AIm < Dij_temp && Dij_temp <= BIm){
		val1 <- BIm-Dij_temp
		val2 <- BIm-AIm
		memX[i,j] <- val1/val2}
            else if (Dij_temp > BIm){
            memX[i,j] <- 0}}}

# Step 5: Predicts Class Labels Using the Fitted Fuzzy Discrimant Model.
# Step 5A: Computes membership values for unknown data points in the Test Matrix.

dimY <- dim(Test_Matrix)
Dij2 <- matrix(0,dimY[1],dim[2])

for (i in 1:dimY[1]){Dij2[i,] <- gower_dist(Test_Matrix[i,],C)}

memY <- matrix(0,dimY[1],dim[2])

for (i in 1:dimY[1]){
for (j in 1:dim[2]){
	Dij2_temp <- Dij2[i,j]
	BIm <- BIm_mat[j]
	AIm <- AI[j]
	if(Dij2_temp <= AIm){
            memY[i,j] <- 1}
            else if (AIm < Dij2_temp && Dij2_temp <= BIm){
		val1 <- BIm-Dij2_temp
		val2 <- BIm-AIm
		memY[i,j] <- val1/val2}
            else if (Dij2_temp > BIm){
            memY[i,j] <- 0}}}

# Step 5B: Checks membership functions for outliers

Decision <- matrix(0,dimY[1],1)

for (i in 1:dimY[1]){
    OD <- memY[i,]
    r <- max(OD)
    if(r==0){
        Decision[i,] <- 0}
    else if(r>0){
        Decision[i,] <- which.max(memY[i,])}}

#Step 5C: Calculates the proportion of taxa which have undergone ecological partitioning.
dim <- dim(memY)
memYp <- matrix(0,dim[1],dim[2])
for (i in 1:dim[1]){
for (j in 1:dim[2]){
if (memY[i,j]==0){
memYp[i,j] <- 0}
else if(memY[i,j]>0){
memYp[i,j] <- 1}}}

Partition <- matrix(0,dim[1],1)
for (i in 1:dim[1]){
VTemp <- sum(memYp[i,])
if(VTemp > 1){Partition[i,] <- 1}}

SumPart <- sum(Partition)
SumRed <- sum(memYp)-SumPart
Proportion_Partitioned <- SumPart/SumRed

#Step 6: Tests membership values against general models of macroevolutionary change.
FVal <- sum(memY)
dim_final <- dim(Test_Matrix)

# Generate model boundaries. 
P_Red <- dim_final[1]*0.75
Neutral <- dim_final[1]/2
P_Exp <- dim_final*0.25

for (i in 1:1){
if(FVal >= dim_final[1]){
Model <- "Total Redundancy"}
if(FVal >= P_Red && FVal < dim_final[1]){
Model <- "Mixed (Redundancy Dominant)"}
if(FVal < P_Red && FVal > Neutral){
Model <- "Neutral (Redundancy Dominant)"}
if(FVal == Neutral){
Model <- "Neutral"}
if(FVal <= Neutral && FVal > P_Exp){
Model <- "Neutral (Expansion Dominant)"}
if(FVal <= P_Exp && FVal > 0){
Model <- "Mixed (Expansion Dominant)"}
if(FVal == 0){
Model <- "Total Expansion"}}

#Step 7: Displays final class values and macroevolutionary model for the Test Matrix. ***See memY for final membership values*** 
print(Decision)
print(Model)
print(Proportion_Partitioned)

